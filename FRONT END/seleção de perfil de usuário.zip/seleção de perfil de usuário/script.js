/* ============================================================
   INÍCIO DO JAVASCRIPT
   ============================================================ */

// Localiza o botão de voltar ao topo no HTML.
const backToTopButton = document.getElementById("backToTop");

// Quando o usuário clicar na seta, a página volta suavemente para o início.
backToTopButton.addEventListener("click", function () {
    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });
});

/* ============================================================
   FIM DO JAVASCRIPT
   ============================================================ */
