# iPawz — Detalhamento de vagas de voluntariado

Projeto incremental com Node.js, Express e MySQL. Nesta etapa, a API consulta uma vaga pelo `id_voluntariado` e retorna os dados da instituição relacionada. A candidatura e o JWT ficaram fora do escopo desta etapa, conforme alinhamento.

## Estrutura

- `backend/src/config`: pool e conexão MySQL.
- `backend/src/repositories`: consulta SQL parametrizada e JOIN com `instituicao`.
- `backend/src/services`: regra de negócio e formatação do objeto de resposta.
- `backend/src/controllers`: tratamento HTTP.
- `backend/src/routes`: endpoint GET.
- `backend/src/validators`: validação do ID com Joi.
- `backend/src/middlewares`: tratamento centralizado de erros.
- `frontend`: HTML, CSS e imagem original, com JavaScript integrado à API.

## Requisitos

- Node.js 18 ou superior (recomendado).
- MySQL em execução e banco `ipawz` criado com as tabelas do arquivo SQL fornecido.

## Configuração

1. Abra um terminal na pasta `backend`.
2. Execute `npm install`.
3. Copie `.env.example` para `.env` e preencha host, porta, usuário, senha e banco MySQL.
4. Ajuste `CORS_ORIGINS` para a origem usada pelo Live Server. Exemplo: `http://127.0.0.1:5500,http://localhost:5500`.
5. Execute `npm run dev`.

## Endpoints

- `GET /api/health` — verifica se a API está ativa.
- `GET /api/voluntariados/:id` — retorna uma vaga pelo ID.

Exemplo: `GET http://localhost:3000/api/voluntariados/1`

Resposta de sucesso (formato ilustrativo; valores reais vêm do banco):

```json
{
  "sucesso": true,
  "dados": {
    "id": 1,
    "titulo": "Título da oportunidade",
    "descricao": "Descrição",
    "requisitos": "Requisitos e informações adicionais",
    "local": "Osasco, SP",
    "dataInicio": "2027-04-17",
    "dataFim": null,
    "quantidadeVagas": 5,
    "status": "Aberta",
    "instituicao": {
      "id": 1,
      "nome": "Nome da instituição",
      "email": "contato@exemplo.org",
      "telefone": "11999999999",
      "cidade": "Osasco",
      "estado": "SP"
    }
  }
}
```

## Observações sobre o esquema recebido

- A tabela `voluntariado` não possui coluna `tipo`; por isso o frontend apresenta `requisitos` sob o título “Requisitos e informações adicionais”. Não foi feita alteração no banco.
- A tabela não possui coluna de imagem; a imagem `frontend/img/vaga-voluntariado.jpg` continua local no frontend.
- O campo `local` e as datas são apresentados diretamente a partir dos dados cadastrados.
- O `LEFT JOIN` permite retornar a vaga mesmo se a instituição relacionada estiver ausente; nesse caso `instituicao` será `null`.
- O ID é validado com Joi e a consulta utiliza placeholder `?` do mysql2 para não concatenar entrada do usuário ao SQL.
- O endpoint de consulta é público. Nenhuma rota de candidatura foi criada nesta etapa. Não envie `id_usuario` pelo navegador para simular autenticação.

## Integração do frontend

Abra `frontend/detalhes-vaga-voluntariado.html` pelo Live Server e informe o ID da vaga na URL:

`http://127.0.0.1:5500/detalhes-vaga-voluntariado.html?id=1`

O JavaScript chama `http://localhost:3000/api/voluntariados/1`. Se usar outra porta ou host no backend, atualize `API_BASE_URL` em `frontend/js/detalhes-vaga-voluntariado.js` e configure a origem no `CORS_ORIGINS` do `.env`.

## Testes manuais recomendados

1. `/api/health` deve retornar HTTP 200.
2. Um ID existente deve retornar HTTP 200 e os dados da vaga.
3. Um ID inexistente deve retornar HTTP 404.
4. ID ausente, texto ou número negativo deve resultar em HTTP 400 (no frontend, a ausência é detectada antes da chamada).
5. O frontend deve exibir erro compreensível se a API estiver desligada.

A conexão real ao banco precisa ser validada no ambiente local, usando as credenciais do responsável pelo projeto.
