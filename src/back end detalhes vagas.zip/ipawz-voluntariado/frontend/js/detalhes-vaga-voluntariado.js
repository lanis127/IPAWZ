// Endereço da API. Em produção, ajuste para o endereço do servidor publicado.
const API_BASE_URL = 'http://localhost:3000/api';

function formatarData(data) {
    if (!data) return 'Não informada';

    // O MySQL pode devolver DATE como string ou como objeto Date, dependendo da configuração.
    const valor = data instanceof Date
        ? `${data.getFullYear()}-${String(data.getMonth() + 1).padStart(2, '0')}-${String(data.getDate()).padStart(2, '0')}`
        : String(data).slice(0, 10);
    const partes = valor.split('-');
    if (partes.length !== 3) return 'Data não disponível';
    return `${partes[2]}/${partes[1]}/${partes[0]}`;
}

function exibirTexto(id, valor, padrao = 'Não informado') {
    document.getElementById(id).textContent = valor || padrao;
}

function exibirDescricao(descricao) {
    const area = document.getElementById('descricao-vaga');
    area.replaceChildren();

    // Cada quebra de linha vira um parágrafo. textContent evita interpretar HTML vindo do banco.
    const paragrafos = String(descricao || 'Descrição não informada.')
        .split(/\r?\n/).map((texto) => texto.trim()).filter(Boolean);

    paragrafos.forEach((texto) => {
        const paragrafo = document.createElement('p');
        paragrafo.textContent = texto;
        area.appendChild(paragrafo);
    });
}

function preencherDetalhes(vaga) {
    exibirTexto('titulo-vaga', vaga.titulo, 'Oportunidade de voluntariado');
    exibirTexto('tipo-vaga', vaga.requisitos, 'Não há requisitos adicionais informados.');
    exibirTexto('localizacao-vaga', vaga.local, 'Local não informado');

    const inicio = formatarData(vaga.dataInicio);
    const fim = formatarData(vaga.dataFim);
    const periodo = vaga.dataInicio && vaga.dataFim
        ? `${inicio} até ${fim}`
        : (vaga.dataInicio ? inicio : (vaga.dataFim ? fim : 'Datas não informadas'));
    exibirTexto('data-vaga', periodo);

    exibirTexto('instituicao-vaga', vaga.instituicao?.nome, 'Instituição não identificada');
    exibirDescricao(vaga.descricao);

    // A tabela voluntariado não possui coluna de imagem; preservamos o arquivo do frontend.
    const imagem = document.getElementById('imagem-vaga');
    imagem.src = 'img/vaga-voluntariado.jpg';
    imagem.alt = `Imagem ilustrativa da oportunidade ${vaga.titulo || ''}`;
}

async function carregarDadosVaga() {
    const parametros = new URLSearchParams(window.location.search);
    const id = parametros.get('id');
    const erroElemento = document.getElementById('erro-vaga');

    if (!id || !/^\d+$/.test(id) || Number(id) < 1) {
        erroElemento.textContent = 'Identificador da vaga ausente ou inválido. Volte à listagem e selecione uma oportunidade.';
        erroElemento.hidden = false;
        document.getElementById('titulo-vaga').textContent = 'Vaga não identificada';
        return;
    }

    try {
        const resposta = await fetch(`${API_BASE_URL}/voluntariados/${encodeURIComponent(id)}`);
        const resultado = await resposta.json();

        if (!resposta.ok) {
            throw new Error(resultado.mensagem || 'Não foi possível carregar os detalhes da vaga.');
        }
        if (!resultado.sucesso || !resultado.dados) {
            throw new Error('A API retornou uma resposta inesperada.');
        }

        preencherDetalhes(resultado.dados);
    } catch (erro) {
        erroElemento.textContent = erro.message || 'Não foi possível conectar ao servidor. Tente novamente.';
        erroElemento.hidden = false;
        document.getElementById('titulo-vaga').textContent = 'Não foi possível carregar a vaga';
        console.error('Erro ao carregar vaga:', erro);
    }
}

// A candidatura continua apenas com aviso provisório nesta etapa, sem enviar dados ao servidor.
function configurarBotaoCandidatura() {
    const botao = document.getElementById('btn-candidatar');
    const mensagem = document.getElementById('mensagem-candidatura');
    botao.addEventListener('click', () => { mensagem.hidden = false; });
}

function configurarSidebar() {
    const abrir = document.getElementById('openMenu');
    const fechar = document.getElementById('closeMenu');
    const sidebar = document.querySelector('.sidebar');
    const overlay = document.getElementById('overlay');

    if (abrir && sidebar && overlay) {
        abrir.addEventListener('click', () => {
            sidebar.classList.add('active');
            overlay.classList.add('active');
            abrir.setAttribute('aria-expanded', 'true');
        });
    }
    function fecharSidebar() {
        if (sidebar) sidebar.classList.remove('active');
        if (overlay) overlay.classList.remove('active');
        if (abrir) abrir.setAttribute('aria-expanded', 'false');
    }
    if (fechar) fechar.addEventListener('click', fecharSidebar);
    if (overlay) overlay.addEventListener('click', fecharSidebar);
}

function configurarVoltarAoTopo() {
    const botaoTopo = document.querySelector('.back-top');
    if (botaoTopo) botaoTopo.addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });
}

document.addEventListener('DOMContentLoaded', () => {
    carregarDadosVaga();
    configurarBotaoCandidatura();
    configurarSidebar();
    configurarVoltarAoTopo();
});
