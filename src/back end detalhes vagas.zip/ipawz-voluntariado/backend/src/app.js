const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const voluntariadoRoutes = require('./routes/voluntariado-routes');
const errorHandler = require('./middlewares/error-handler');

const app = express();
const origensPermitidas = (process.env.CORS_ORIGINS || '')
    .split(',').map((origem) => origem.trim()).filter(Boolean);

app.use(helmet());
app.use(cors({
    origin(origem, callback) {
        // Permite ferramentas sem origem (ex.: curl/Postman) e origens cadastradas.
        if (!origem || origensPermitidas.includes(origem)) return callback(null, true);
        return callback(new Error('Origem não permitida pelo CORS.'));
    }
}));
app.use(express.json({ limit: '20kb' }));

app.get('/api/health', (req, res) => {
    res.status(200).json({ sucesso: true, mensagem: 'API iPawz ativa.' });
});
app.use('/api/voluntariados', voluntariadoRoutes);
app.use((req, res) => res.status(404).json({ sucesso: false, mensagem: 'Rota não encontrada.' }));
app.use(errorHandler);

module.exports = app;
