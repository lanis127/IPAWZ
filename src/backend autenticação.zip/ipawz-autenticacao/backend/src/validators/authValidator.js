const { body, validationResult } = require("express-validator");

const validarCadastro = [
    body("nome").trim().notEmpty().withMessage("Nome é obrigatório.").isLength({ max: 150 }).withMessage("Nome deve ter até 150 caracteres."),
    body("dataNascimento").isISO8601({ strict: true }).withMessage("Data de nascimento inválida."),
    body("telefone").trim().notEmpty().withMessage("Telefone é obrigatório.").isLength({ max: 20 }).withMessage("Telefone deve ter até 20 caracteres."),
    body("estado").trim().isLength({ min: 2, max: 2 }).withMessage("Informe uma UF com duas letras.").isAlpha("pt-BR").withMessage("UF inválida.").toUpperCase(),
    body("email").trim().isEmail().withMessage("E-mail inválido.").normalizeEmail().isLength({ max: 150 }),
    body("senha").isString().isLength({ min: 8, max: 72 }).withMessage("A senha deve possuir entre 8 e 72 caracteres."),
    body("confirmarSenha").custom((valor, { req }) => valor === req.body.senha).withMessage("As senhas não coincidem.")
];

const validarLogin = [
    body("email").trim().isEmail().withMessage("E-mail inválido.").normalizeEmail(),
    body("senha").isString().notEmpty().withMessage("Senha é obrigatória.")
];

function tratarErrosValidacao(req, res, next) {
    const erros = validationResult(req);
    if (!erros.isEmpty()) {
        return res.status(400).json({
            mensagem: "Verifique os dados informados.",
            erros: erros.array().map(({ path, msg }) => ({ campo: path, mensagem: msg }))
        });
    }
    next();
}

module.exports = { validarCadastro, validarLogin, tratarErrosValidacao };
