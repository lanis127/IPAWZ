const authService = require("../services/authService");

async function cadastrar(req, res, next) {
    try {
        const usuario = await authService.cadastrar(req.body);
        return res.status(201).json({
            mensagem: "Cadastro realizado com sucesso. Você já pode fazer login.",
            usuario
        });
    } catch (erro) {
        next(erro);
    }
}

async function login(req, res, next) {
    try {
        const resultado = await authService.login(req.body.email, req.body.senha);
        return res.status(200).json({
            mensagem: "Login realizado com sucesso.",
            ...resultado
        });
    } catch (erro) {
        next(erro);
    }
}

module.exports = { cadastrar, login };
