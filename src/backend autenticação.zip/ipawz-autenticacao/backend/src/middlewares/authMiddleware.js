const jwt = require("jsonwebtoken");

function autenticar(req, res, next) {
    const cabecalho = req.headers.authorization;
    if (!cabecalho || !cabecalho.startsWith("Bearer ")) {
        return res.status(401).json({ mensagem: "Autenticação necessária. Informe um token Bearer." });
    }

    const token = cabecalho.slice(7).trim();
    if (!token) {
        return res.status(401).json({ mensagem: "Token não informado." });
    }

    try {
        req.usuario = jwt.verify(token, process.env.JWT_SECRET, {
            issuer: "ipawz-api",
            audience: "ipawz-web"
        });
        return next();
    } catch {
        return res.status(401).json({ mensagem: "Token inválido ou expirado." });
    }
}

module.exports = autenticar;
