function exigirVoluntario(req, res, next) {
    if (!req.usuario || req.usuario.perfil !== "Voluntário") {
        return res.status(403).json({ mensagem: "Acesso permitido somente para usuários voluntários." });
    }
    return next();
}

module.exports = { exigirVoluntario };
