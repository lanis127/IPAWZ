function errorHandler(erro, req, res, next) {
    console.error(erro);

    const status = erro.statusCode || (erro.code === "PERFIL_NAO_CONFIGURADO" ? 500 : 500);
    const mensagem = erro.statusCode || erro.code === "PERFIL_NAO_CONFIGURADO"
        ? erro.message
        : "Ocorreu um erro interno. Tente novamente mais tarde.";

    return res.status(status).json({ mensagem });
}

module.exports = errorHandler;
