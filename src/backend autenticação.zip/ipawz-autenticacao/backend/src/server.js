require("dotenv").config();

const express = require("express");
const cors = require("cors");
const pool = require("./config/database");
const authRoutes = require("./routes/authRoutes");
const usuarioRoutes = require("./routes/usuarioRoutes");
const errorHandler = require("./middlewares/errorHandler");

if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32) {
    throw new Error("Configure JWT_SECRET no .env com pelo menos 32 caracteres.");
}

const app = express();
const PORT = Number(process.env.PORT || 3000);
const origensPermitidas = (process.env.CORS_ORIGINS || "http://127.0.0.1:5500,http://localhost:5500")
    .split(",").map((origem) => origem.trim()).filter(Boolean);

app.use(cors({
    origin(origem, callback) {
        if (!origem || origensPermitidas.includes(origem)) return callback(null, true);
        return callback(new Error("Origem não permitida pelo CORS."));
    }
}));
app.use(express.json({ limit: "20kb" }));

app.get("/api/health", (req, res) => res.json({ status: "ok", servico: "ipawz-autenticacao" }));
app.use("/api/auth", authRoutes);
app.use("/api/usuario", usuarioRoutes);
app.use(errorHandler);

async function iniciarServidor() {
    try {
        await pool.query("SELECT 1");
        app.listen(PORT, () => console.log(`API iPawz disponível em http://localhost:${PORT}`));
    } catch (erro) {
        console.error("Falha ao conectar ao MySQL:", erro.message);
        process.exit(1);
    }
}

iniciarServidor();
