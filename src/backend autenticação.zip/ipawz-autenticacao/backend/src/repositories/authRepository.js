const pool = require("../config/database");

async function buscarPorEmail(email) {
    const [rows] = await pool.execute(
        `SELECT u.id_usuario, u.nome, u.email, u.senha_hash, u.status,
                u.id_perfil, p.nome AS perfil
           FROM usuario u
           LEFT JOIN perfil p ON p.id_perfil = u.id_perfil
          WHERE u.email = ?
          LIMIT 1`,
        [email]
    );
    return rows[0] || null;
}

async function buscarPerfilVoluntario(connection) {
    const [rows] = await connection.execute(
        "SELECT id_perfil FROM perfil WHERE nome = ? LIMIT 1",
        ["Voluntário"]
    );
    return rows[0] || null;
}

async function criarUsuario(dados) {
    const connection = await pool.getConnection();
    try {
        await connection.beginTransaction();
        const perfil = await buscarPerfilVoluntario(connection);
        if (!perfil) {
            const erro = new Error("Perfil Voluntário não cadastrado. Execute a migração SQL.");
            erro.code = "PERFIL_NAO_CONFIGURADO";
            throw erro;
        }

        const [resultado] = await connection.execute(
            `INSERT INTO usuario
                (nome, cpf, data_nascimento, email, senha_hash, telefone, estado, id_perfil)
             VALUES (?, NULL, ?, ?, ?, ?, ?, ?)`,
            [dados.nome, dados.dataNascimento, dados.email, dados.senhaHash, dados.telefone, dados.estado, perfil.id_perfil]
        );

        await connection.commit();
        return resultado.insertId;
    } catch (erro) {
        await connection.rollback();
        throw erro;
    } finally {
        connection.release();
    }
}

module.exports = { buscarPorEmail, criarUsuario };
