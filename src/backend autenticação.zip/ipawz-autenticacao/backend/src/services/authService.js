const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const repository = require("../repositories/authRepository");

async function cadastrar(dados) {
    const existente = await repository.buscarPorEmail(dados.email);
    if (existente) {
        const erro = new Error("Este e-mail já está cadastrado.");
        erro.statusCode = 409;
        throw erro;
    }

    const rounds = Number(process.env.BCRYPT_ROUNDS || 12);
    const senhaHash = await bcrypt.hash(dados.senha, rounds);

    try {
        const id = await repository.criarUsuario({
            ...dados,
            senhaHash
        });
        return { id, nome: dados.nome, email: dados.email, perfil: "Voluntário" };
    } catch (erro) {
        // A restrição UNIQUE do banco também protege contra cadastros simultâneos.
        if (erro.code === "ER_DUP_ENTRY") {
            const conflito = new Error("Este e-mail já está cadastrado.");
            conflito.statusCode = 409;
            throw conflito;
        }
        throw erro;
    }
}

async function login(email, senha) {
    const usuario = await repository.buscarPorEmail(email);

    // A mesma mensagem é usada para e-mail inexistente e senha incorreta.
    if (!usuario || !usuario.status) {
        const erro = new Error("E-mail ou senha inválidos.");
        erro.statusCode = 401;
        throw erro;
    }

    const senhaCorreta = await bcrypt.compare(senha, usuario.senha_hash);
    if (!senhaCorreta) {
        const erro = new Error("E-mail ou senha inválidos.");
        erro.statusCode = 401;
        throw erro;
    }

    if (usuario.perfil !== "Voluntário") {
        const erro = new Error("Este acesso está disponível somente para contas de voluntário.");
        erro.statusCode = 403;
        throw erro;
    }

    const token = jwt.sign(
        { id: usuario.id_usuario, email: usuario.email, perfil: usuario.perfil },
        process.env.JWT_SECRET,
        { expiresIn: process.env.JWT_EXPIRES_IN || "1h", issuer: "ipawz-api", audience: "ipawz-web" }
    );

    return {
        token,
        usuario: {
            id: usuario.id_usuario,
            nome: usuario.nome,
            email: usuario.email,
            perfil: usuario.perfil
        }
    };
}

module.exports = { cadastrar, login };
