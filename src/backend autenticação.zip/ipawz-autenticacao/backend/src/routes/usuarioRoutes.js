const express = require("express");
const autenticar = require("../middlewares/authMiddleware");
const { exigirVoluntario } = require("../middlewares/perfilMiddleware");

const router = express.Router();

router.get("/me", autenticar, exigirVoluntario, (req, res) => {
    return res.status(200).json({
        usuario: {
            id: req.usuario.id,
            email: req.usuario.email,
            perfil: req.usuario.perfil
        }
    });
});

module.exports = router;
