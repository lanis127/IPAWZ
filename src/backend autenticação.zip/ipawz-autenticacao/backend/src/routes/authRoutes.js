const express = require("express");
const controller = require("../controllers/authController");
const { validarCadastro, validarLogin, tratarErrosValidacao } = require("../validators/authValidator");

const router = express.Router();

router.post("/cadastro", validarCadastro, tratarErrosValidacao, controller.cadastrar);
router.post("/login", validarLogin, tratarErrosValidacao, controller.login);

module.exports = router;
