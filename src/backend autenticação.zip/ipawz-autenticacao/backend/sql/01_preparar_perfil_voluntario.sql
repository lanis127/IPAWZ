USE ipawz;

-- Faça backup antes de executar. O script pode ser executado novamente sem
-- tentar adicionar uma segunda vez a coluna id_perfil ou a chave estrangeira.

INSERT INTO perfil (nome, descricao)
VALUES ('Voluntário', 'Pessoa física que utiliza as funcionalidades de voluntariado')
ON DUPLICATE KEY UPDATE descricao = VALUES(descricao);

-- O formulário atual não solicita CPF. Mantemos a coluna, mas permitimos NULL.
-- A restrição UNIQUE continua valendo para CPFs que forem informados no futuro.
ALTER TABLE usuario MODIFY cpf CHAR(11) NULL;

-- Adiciona id_perfil somente se a coluna ainda não existir.
SET @coluna_existe = (
    SELECT COUNT(*)
      FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = DATABASE()
       AND TABLE_NAME = 'usuario'
       AND COLUMN_NAME = 'id_perfil'
);
SET @sql_coluna = IF(
    @coluna_existe = 0,
    'ALTER TABLE usuario ADD COLUMN id_perfil INT NULL AFTER id_usuario',
    'SELECT ''Coluna id_perfil já existe'' AS aviso'
);
PREPARE stmt_coluna FROM @sql_coluna;
EXECUTE stmt_coluna;
DEALLOCATE PREPARE stmt_coluna;

-- Classifica como voluntárias as contas PF já existentes sem perfil.
UPDATE usuario
   SET id_perfil = (SELECT id_perfil FROM perfil WHERE nome = 'Voluntário' LIMIT 1)
 WHERE id_perfil IS NULL;

ALTER TABLE usuario MODIFY id_perfil INT NOT NULL;

-- Adiciona a FK somente se ela ainda não existir.
SET @fk_existe = (
    SELECT COUNT(*)
      FROM information_schema.TABLE_CONSTRAINTS
     WHERE CONSTRAINT_SCHEMA = DATABASE()
       AND TABLE_NAME = 'usuario'
       AND CONSTRAINT_NAME = 'fk_usuario_perfil'
       AND CONSTRAINT_TYPE = 'FOREIGN KEY'
);
SET @sql_fk = IF(
    @fk_existe = 0,
    'ALTER TABLE usuario ADD CONSTRAINT fk_usuario_perfil FOREIGN KEY (id_perfil) REFERENCES perfil(id_perfil)',
    'SELECT ''Chave estrangeira fk_usuario_perfil já existe'' AS aviso'
);
PREPARE stmt_fk FROM @sql_fk;
EXECUTE stmt_fk;
DEALLOCATE PREPARE stmt_fk;
