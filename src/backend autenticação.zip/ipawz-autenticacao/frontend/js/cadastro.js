const API_URL = "http://localhost:3000/api/auth";

const form = document.getElementById("form-cadastro");
const mensagem = document.getElementById("mensagem-cadastro");

form.addEventListener("submit", async (event) => {
    event.preventDefault();
    mensagem.textContent = "";

    const dados = {
        nome: document.getElementById("nome").value.trim(),
        dataNascimento: document.getElementById("dataNascimento").value,
        telefone: document.getElementById("telefone").value.trim(),
        estado: document.getElementById("estado").value,
        email: document.getElementById("email").value.trim(),
        senha: document.getElementById("senha").value,
        confirmarSenha: document.getElementById("confirmarSenha").value
    };

    if (dados.senha !== dados.confirmarSenha) {
        mensagem.textContent = "As senhas não coincidem.";
        return;
    }

    try {
        const resposta = await fetch(`${API_URL}/cadastro`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(dados)
        });
        const resultado = await resposta.json();

        if (!resposta.ok) {
            mensagem.textContent = resultado.mensagem || "Não foi possível realizar o cadastro.";
            return;
        }

        mensagem.textContent = "Cadastro realizado com sucesso! Você já pode fazer login.";
        form.reset();
    } catch (erro) {
        console.error(erro);
        mensagem.textContent = "Não foi possível conectar ao servidor. Verifique se o backend está ativo.";
    }
});
