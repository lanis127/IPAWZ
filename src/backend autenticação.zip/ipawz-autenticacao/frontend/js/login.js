const API_URL = "http://localhost:3000/api/auth";

const form = document.getElementById("form-login");
const mensagem = document.getElementById("mensagem-login");

form.addEventListener("submit", async (event) => {
    event.preventDefault();
    mensagem.textContent = "";

    const dados = {
        email: document.getElementById("email").value.trim(),
        senha: document.getElementById("senha").value
    };

    try {
        const resposta = await fetch(`${API_URL}/login`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(dados)
        });
        const resultado = await resposta.json();

        if (!resposta.ok) {
            mensagem.textContent = resultado.mensagem || "E-mail ou senha inválidos.";
            return;
        }

        // O token é guardado para ser enviado nas próximas chamadas protegidas.
        sessionStorage.setItem("ipawz_token", resultado.token);
        sessionStorage.setItem("ipawz_usuario", JSON.stringify(resultado.usuario));

        mensagem.textContent = "Login realizado com sucesso!";
        // Ajuste o destino quando a página inicial definitiva estiver definida.
        // window.location.href = "../index.html";
    } catch (erro) {
        console.error(erro);
        mensagem.textContent = "Não foi possível conectar ao servidor. Verifique se o backend está ativo.";
    }
});
