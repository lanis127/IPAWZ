# iPawz — Cadastro e login

Projeto integrado de cadastro de pessoa física e login com Node.js, Express, MySQL, bcrypt e JWT.

## Decisões desta implementação

- O cadastro atual não solicita CPF, conforme orientação. Por isso, a migração torna `usuario.cpf` nullable, mantendo a restrição UNIQUE.
- O perfil `Voluntário` é atribuído exclusivamente pelo backend.
- A senha é armazenada em `senha_hash` usando bcrypt.
- O login compara a senha informada com o hash e gera um JWT com validade configurável.
- O token inclui `id`, `email` e `perfil`; as rotas protegidas devem usar o middleware `authMiddleware`.
- O exemplo de rota `/api/usuario/me` exige JWT e perfil Voluntário.
- Não foi incluído redirecionamento automático após login porque o caminho definitivo da página inicial não foi fornecido.

## 1. Banco de dados

Faça backup do banco `ipawz` antes de alterar a estrutura.

O SQL original declara `cpf CHAR(10) NOT NULL`, mas o formulário não coleta CPF. O script `backend/sql/01_preparar_perfil_voluntario.sql` altera a coluna para `CHAR(11) NULL`, cria/garante o perfil Voluntário e adiciona `id_perfil` à tabela `usuario`.

**Atenção:** o script de migração foi escrito para ser executado uma única vez. Se `id_perfil` ou a constraint `fk_usuario_perfil` já existirem no seu banco, revise/remova os comandos duplicados antes de executar.

Se a tabela `usuario` já possuir dados, o script classifica os registros sem perfil como Voluntário. Confirme que isso corresponde ao uso atual da base antes de executar.

## 2. Configuração

No terminal:

```bash
cd backend
npm install
```

Copie `.env.example` para `.env` e preencha os dados reais do MySQL. Defina `JWT_SECRET` com uma chave aleatória longa (mínimo 32 caracteres). Não compartilhe nem envie o arquivo `.env`.

Inicie:

```bash
npm run dev
```

A API inicia em `http://localhost:3000`.

## 3. Endpoints

### Cadastro
`POST /api/auth/cadastro`

```json
{
  "nome": "Nome Sobrenome",
  "dataNascimento": "2000-01-31",
  "telefone": "11999999999",
  "estado": "SP",
  "email": "usuario@exemplo.com",
  "senha": "umaSenhaForte123",
  "confirmarSenha": "umaSenhaForte123"
}
```

`confirmarSenha` é conferida no frontend. O backend valida os campos utilizados para persistência.

### Login
`POST /api/auth/login`

```json
{
  "email": "usuario@exemplo.com",
  "senha": "umaSenhaForte123"
}
```

A resposta inclui `token` e dados básicos do usuário.

### Validar sessão
`GET /api/usuario/me`

Enviar o cabeçalho:

`Authorization: Bearer SEU_TOKEN`

### Saúde da API
`GET /api/health`

## 4. Frontend

Abra `frontend/auth/cadastro-pf.html` e `frontend/auth/login.html` pelo Live Server. O JavaScript usa `sessionStorage` com as chaves `ipawz_token` e `ipawz_usuario`.

Se o Live Server usar outra porta, inclua a origem no `CORS_ORIGINS` do `.env` e reinicie o servidor.

Os HTML enviados referenciam `../css/signInOut.css` e imagens em `../assets/icons/`. Esses recursos visuais não estavam incluídos no ZIP recebido. Copie-os do frontend completo para os caminhos correspondentes. Os formulários e scripts de integração estão preservados no projeto.

## 5. Testes recomendados

1. `GET /api/health` deve retornar `status: ok`.
2. Cadastrar um usuário com dados válidos deve retornar HTTP 201.
3. Repetir o mesmo e-mail deve retornar HTTP 409.
4. Fazer login com senha errada deve retornar HTTP 401.
5. Fazer login com credenciais corretas deve retornar HTTP 200 e token.
6. Acessar `/api/usuario/me` sem token deve retornar HTTP 401.
7. Acessar `/api/usuario/me` com token válido de voluntário deve retornar HTTP 200.

## Limitações conhecidas

Não foi possível testar a conexão com um servidor MySQL real, pois as credenciais pertencem ao ambiente local. Os arquivos JavaScript foram verificados sintaticamente. O projeto ainda precisa ser executado no ambiente do usuário para validar a migração e as consultas reais.
