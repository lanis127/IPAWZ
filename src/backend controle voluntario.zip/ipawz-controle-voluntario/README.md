# iPawz — controle de acesso do voluntário

Esta versão reúne o backend de detalhamento de vagas desenvolvido anteriormente com o cadastro/login e a autorização por perfil de voluntário.

## Regras consideradas

**Permitido ao perfil Voluntário:** realizar doação, candidatar-se a vagas de voluntariado e acompanhar as próprias candidaturas.

**Bloqueado ao perfil Voluntário:** solicitar adoção e acompanhar solicitações de adoção.

A visualização dos detalhes das vagas continua pública. O cadastro de pessoa física atribui o perfil `Voluntário` no próprio backend; a API não aceita `id_perfil` ou nome de perfil enviado pelo navegador.

## 1. Preparar o banco

1. Faça um backup do banco `ipawz`.
2. Abra o MySQL Workbench e selecione o banco `ipawz`.
3. Execute uma única vez o arquivo `backend/sql/01_perfil_voluntario.sql`.

O script:
- ajusta o CPF para 11 caracteres (o SQL recebido definia `CHAR(10)`, embora CPF tenha 11 dígitos);
- cadastra o perfil `Voluntário`;
- adiciona `id_perfil` à tabela `usuario`;
- atribui o perfil Voluntário aos usuários existentes, considerando que os registros atuais são contas pessoa física;
- cria a chave estrangeira.

**Importante:** se já houver usuários de outros tipos na tabela `usuario`, não execute a atribuição em massa sem antes separar esses registros. O script é uma migração para o cenário atual informado, em que o cadastro enviado é de pessoa física.

## 2. Configurar o backend

No terminal:

```bash
cd backend
npm install
```

Copie `.env.example` para `.env` e informe os dados reais do MySQL. Troque `JWT_SECRET` por uma chave longa, aleatória e privada. Não compartilhe nem envie o `.env`.

Inicie:

```bash
npm run dev
```

A API inicia em `http://localhost:3000`.

## 3. Rotas disponíveis nesta entrega

| Método | Rota | Acesso |
|---|---|---|
| POST | `/api/auth/cadastro` | Público; cria conta com perfil Voluntário |
| POST | `/api/auth/login` | Público; retorna JWT |
| GET | `/api/usuario/permissoes` | Autenticado; retorna permissões do usuário |
| GET | `/api/voluntariados/:id` | Público; consulta detalhes da vaga |
| GET | `/api/health` | Público; verifica a API |

O endpoint `/api/usuario/permissoes` exige o cabeçalho:

```http
Authorization: Bearer SEU_TOKEN
```

Ele retorna as permissões do perfil autenticado. O frontend pode usar essa resposta para exibir ou ocultar opções, mas isso é apenas apresentação: as rotas de cada funcionalidade também precisam usar os middlewares no servidor.

## 4. Como aplicar as restrições nas rotas de funcionalidades

Os middlewares estão em `backend/src/middlewares/perfil-middleware.js`:

- `exigirPerfil('Voluntário')`: só permite o perfil Voluntário;
- `negarPerfil('Voluntário')`: impede o perfil Voluntário.

Exemplo para as rotas de doação e candidatura (quando esses routers forem integrados):

```js
const autenticar = require('../middlewares/auth-middleware');
const { exigirPerfil } = require('../middlewares/perfil-middleware');

router.use(autenticar, exigirPerfil('Voluntário'));
```

Exemplo para rotas de solicitação e acompanhamento de adoção:

```js
const autenticar = require('../middlewares/auth-middleware');
const { negarPerfil } = require('../middlewares/perfil-middleware');

router.use(autenticar, negarPerfil('Voluntário'));
```

O `autenticar` deve vir antes do middleware de perfil. Assim, quem não está logado recebe `401`; quem está logado, mas não tem autorização, recebe `403`.

**Limite desta entrega:** o ZIP recebido não continha routers/controllers de doação, candidatura, solicitação de adoção ou acompanhamento de adoção. Por isso, os middlewares e os exemplos de aplicação estão prontos, mas não criei endpoints fictícios nem afirmei que essas quatro funcionalidades já estão implementadas. Quando os respectivos backends forem integrados, basta aplicar os middlewares nos routers reais.

## 5. Cadastro e login no frontend

Foram incluídas cópias das páginas enviadas em `frontend/auth/`, com os campos `id`/`name` necessários e scripts de integração:

- `frontend/auth/cadastro-pf.html`
- `frontend/auth/js/cadastro.js`
- `frontend/auth/login.html`
- `frontend/auth/js/login.js`

O formulário de cadastro agora solicita CPF, pois a tabela `usuario` exige esse dado. O cadastro atribui o perfil no servidor. O login guarda o token em `sessionStorage` para uso durante a sessão.

As páginas continuam referenciando a folha de estilo e os ícones do protótipo original (`../css/signInOut.css` e `../assets/icons/`). Copie esses recursos para os caminhos correspondentes no projeto completo do frontend, se ainda não estiverem lá.

## 6. Teste manual sugerido

1. Execute a migração SQL.
2. Inicie o backend e abra o cadastro pelo Live Server.
3. Cadastre uma pessoa física com CPF válido (11 dígitos), e-mail e senha de pelo menos 8 caracteres.
4. Faça login com a conta criada.
5. No navegador, consulte `/api/usuario/permissoes` enviando o token Bearer. O retorno deve indicar `realizarDoacao`, `candidatarSeVoluntariado` e `acompanharCandidaturas` como `true`, e `solicitarAdocao` e `acompanharAdocao` como `false`.
6. Aplique os middlewares nas rotas reais de adoção/doação/candidatura quando esses módulos forem adicionados.

## Observações técnicas

- O middleware consulta novamente o perfil e o status no banco em cada requisição protegida; assim, a autorização não depende somente de um dado antigo guardado no JWT.
- Não envie `id_usuario` do frontend para definir de quem é uma candidatura ou doação. Nas funcionalidades autenticadas, use `req.usuario.id`, preenchido pelo middleware.
- A integração real com MySQL depende das credenciais locais e deve ser testada no ambiente do projeto. A validação de sintaxe dos arquivos JavaScript foi realizada, mas não houve conexão com o banco local nesta execução.
