const formLogin = document.getElementById('form-login');
const mensagemLogin = document.getElementById('mensagem-login');

formLogin.addEventListener('submit', async (evento) => {
    evento.preventDefault();
    mensagemLogin.textContent = '';

    try {
        const resposta = await fetch('http://localhost:3000/api/auth/login', {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                email: document.getElementById('email').value.trim(),
                senha: document.getElementById('senha').value
            })
        });
        const resultado = await resposta.json();
        if (!resposta.ok) throw new Error(resultado.mensagem || 'Não foi possível realizar o login.');
        sessionStorage.setItem('ipawzToken', resultado.token);
        sessionStorage.setItem('ipawzUsuario', JSON.stringify(resultado.usuario));
        mensagemLogin.textContent = `Bem-vindo(a), ${resultado.usuario.nome}! Perfil: ${resultado.usuario.perfil}.`;
    } catch (erro) {
        mensagemLogin.textContent = erro.message;
    }
});
