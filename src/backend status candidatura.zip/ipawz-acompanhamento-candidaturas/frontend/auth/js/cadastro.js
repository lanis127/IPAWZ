const formCadastro = document.getElementById('form-cadastro');
const mensagemCadastro = document.getElementById('mensagem-cadastro');

formCadastro.addEventListener('submit', async (evento) => {
    evento.preventDefault();
    mensagemCadastro.textContent = '';

    const dados = {
        nome: document.getElementById('nome').value.trim(),
        cpf: document.getElementById('cpf').value.replace(/\D/g, ''),
        dataNascimento: document.getElementById('dataNascimento').value,
        telefone: document.getElementById('telefone').value.trim(),
        estado: document.getElementById('estado').value,
        email: document.getElementById('email').value.trim(),
        senha: document.getElementById('senha').value
    };

    if (dados.senha !== document.getElementById('confirmarSenha').value) {
        mensagemCadastro.textContent = 'As senhas não coincidem.';
        return;
    }

    try {
        const resposta = await fetch('http://localhost:3000/api/auth/cadastro', {
            method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(dados)
        });
        const resultado = await resposta.json();
        if (!resposta.ok) throw new Error(resultado.mensagem || 'Não foi possível realizar o cadastro.');
        mensagemCadastro.textContent = 'Cadastro de voluntário realizado! Você já pode entrar na sua conta.';
        formCadastro.reset();
    } catch (erro) {
        mensagemCadastro.textContent = erro.message;
    }
});
