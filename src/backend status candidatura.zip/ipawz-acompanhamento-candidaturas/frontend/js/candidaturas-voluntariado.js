// =========================================================
// TELA: ACOMPANHAMENTO DE CANDIDATURAS - IPAWZ
// Agora os dados vêm da API; não são mais cadastrados neste arquivo.
// O filtro de status é enviado ao backend para consultar o MySQL.
// =========================================================

const API_BASE_URL = 'http://localhost:3000/api';

const applicationsList = document.getElementById('applicationsList');
const resultsMessage = document.getElementById('resultsMessage');
const filterPanel = document.getElementById('filterPanel');
const filterBackdrop = document.getElementById('filterBackdrop');
const openFilterButton = document.getElementById('openFilter');
const closeFilterButton = document.getElementById('closeFilter');
const filterForm = document.getElementById('filterForm');
const clearFiltersButton = document.getElementById('clearFilters');

let statusSelecionado = null;

const nomesStatus = {
  aceita: 'Aceita',
  aguardando: 'Aguardando resposta',
  negada: 'Negada'
};

const etapas = [
  'Candidatura<br>Enviada',
  'Candidatura<br>Recebida',
  'Currículo<br>em Análise',
  'Candidato<br>Aceito(a)'
];

function criarLinhaDoTempo(candidatura) {
  const nomesEtapas = [...etapas];

  if (candidatura.status === 'negada') {
    nomesEtapas[3] = 'Candidatura<br>Negada';
  } else if (candidatura.status === 'aguardando') {
    nomesEtapas[3] = 'Aguardando<br>resposta';
  }

  // etapa é um número de 1 a 3; limitamos o valor para proteger a renderização.
  const etapaInformada = Number(candidatura.etapa);
  const passoAtual = candidatura.status === 'aguardando'
    ? Math.min(3, Math.max(1, Number.isInteger(etapaInformada) ? etapaInformada : 1))
    : 3;

  return `
    <div class="timeline" style="--step-count: ${nomesEtapas.length}">
      ${nomesEtapas.map((nome, indice) => {
        const concluido = indice < passoAtual ||
          (candidatura.status !== 'aguardando' && indice === 3);
        const atual = candidatura.status === 'aguardando' && indice === passoAtual;
        const final = indice === 3 && candidatura.status !== 'aguardando';
        const classe = [
          'timeline-step',
          concluido ? 'is-complete' : '',
          atual ? 'is-current' : '',
          final ? 'is-final' : ''
        ].filter(Boolean).join(' ');

        let simbolo = '';
        if (final && candidatura.status === 'aceita') simbolo = '✓';
        if (final && candidatura.status === 'negada') simbolo = '×';

        return `
          <div class="${classe}">
            <span class="timeline-dot">${simbolo}</span>
            <span class="timeline-label">${nome}</span>
          </div>
        `;
      }).join('')}
    </div>
  `;
}

function criarCartao(candidatura) {
  const cartao = document.createElement('article');
  cartao.className = 'application-card';

  // Os dados vindos do banco são inseridos com textContent para evitar HTML injetado.
  const topo = document.createElement('div');
  topo.className = 'application-topline';

  const campoData = document.createElement('span');
  campoData.textContent = `Data Candidatura: ${candidatura.data || 'Não informada'}`;

  const campoVaga = document.createElement('span');
  campoVaga.textContent = `Vaga: ${candidatura.vaga || 'Não informada'}`;

  const campoInstituicao = document.createElement('span');
  campoInstituicao.textContent = `Instituição: ${candidatura.instituicao || 'Não informada'}`;

  const status = document.createElement('span');
  status.className = 'status-pill';
  status.textContent = nomesStatus[candidatura.status] || 'Status não informado';

  topo.append(campoData, campoVaga, campoInstituicao, status);

  const conteudo = document.createElement('div');
  conteudo.className = 'application-content';
  conteudo.innerHTML = criarLinhaDoTempo(candidatura);

  const rodape = document.createElement('div');
  rodape.className = 'application-footer';

  const linkDetalhes = document.createElement('a');
  linkDetalhes.className = 'details-link';
  linkDetalhes.href = '#';
  linkDetalhes.dataset.detailsId = String(candidatura.id);
  linkDetalhes.textContent = 'VER DETALHES';
  rodape.appendChild(linkDetalhes);

  conteudo.appendChild(rodape);
  cartao.append(topo, conteudo);
  return cartao;
}

function renderizarCandidaturas(candidaturas) {
  applicationsList.innerHTML = '';

  if (!Array.isArray(candidaturas) || candidaturas.length === 0) {
    resultsMessage.textContent = statusSelecionado
      ? 'Nenhuma candidatura encontrada para este status.'
      : 'Você ainda não possui candidaturas de voluntariado.';
    return;
  }

  resultsMessage.textContent = statusSelecionado
    ? `Exibindo ${candidaturas.length} candidatura(s): ${nomesStatus[statusSelecionado]}.`
    : '';

  candidaturas.forEach(candidatura => {
    applicationsList.appendChild(criarCartao(candidatura));
  });
}

async function carregarCandidaturas(status = null) {
  const token = sessionStorage.getItem('ipawzToken');

  applicationsList.innerHTML = '';
  resultsMessage.textContent = 'Carregando suas candidaturas...';

  if (!token) {
    resultsMessage.textContent = 'Para acompanhar suas candidaturas, faça login na sua conta de voluntário.';
    return;
  }

  const parametros = new URLSearchParams();
  if (status) parametros.set('status', status);
  const query = parametros.toString();
  const url = `${API_BASE_URL}/candidaturas${query ? `?${query}` : ''}`;

  try {
    const resposta = await fetch(url, {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: 'application/json'
      }
    });

    const resultado = await resposta.json();

    if (resposta.status === 401) {
      throw new Error('Sua sessão expirou ou não é válida. Entre novamente para continuar.');
    }
    if (resposta.status === 403) {
      throw new Error('Esta área é exclusiva para usuários com perfil de voluntário.');
    }
    if (!resposta.ok) {
      throw new Error(resultado.mensagem || 'Não foi possível carregar as candidaturas.');
    }

    renderizarCandidaturas(resultado.candidaturas);
  } catch (erro) {
    applicationsList.innerHTML = '';
    resultsMessage.textContent = erro.message || 'Não foi possível conectar ao servidor. Verifique se o backend está em execução.';
  }
}

function abrirFiltro() {
  filterPanel.classList.add('is-open');
  filterPanel.setAttribute('aria-hidden', 'false');
  filterBackdrop.hidden = false;
  openFilterButton.setAttribute('aria-expanded', 'true');
}

function fecharFiltro() {
  filterPanel.classList.remove('is-open');
  filterPanel.setAttribute('aria-hidden', 'true');
  filterBackdrop.hidden = true;
  openFilterButton.setAttribute('aria-expanded', 'false');
}

openFilterButton.addEventListener('click', abrirFiltro);
closeFilterButton.addEventListener('click', fecharFiltro);
filterBackdrop.addEventListener('click', fecharFiltro);

filterForm.addEventListener('submit', async event => {
  event.preventDefault();
  const opcaoMarcada = filterForm.querySelector('input[name="status"]:checked');
  statusSelecionado = opcaoMarcada ? opcaoMarcada.value : null;
  fecharFiltro();
  await carregarCandidaturas(statusSelecionado);
});

clearFiltersButton.addEventListener('click', async () => {
  statusSelecionado = null;
  filterForm.reset();
  fecharFiltro();
  await carregarCandidaturas();
});

// O link de detalhes permanece reservado, conforme o protótipo recebido.
applicationsList.addEventListener('click', event => {
  const linkDetalhes = event.target.closest('.details-link');
  if (!linkDetalhes) return;
  event.preventDefault();
});

/* =========================================================
   MENU LATERAL (SIDEBAR)
   ========================================================= */
const openMenuButton = document.getElementById('openMenu');
const closeMenuButton = document.getElementById('closeMenu');
const sidebar = document.getElementById('sidebar');
const overlay = document.getElementById('overlay');

function abrirMenu() {
  sidebar.classList.add('active');
  overlay.classList.add('active');
  openMenuButton.setAttribute('aria-expanded', 'true');
}

function fecharMenu() {
  sidebar.classList.remove('active');
  overlay.classList.remove('active');
  openMenuButton.setAttribute('aria-expanded', 'false');
}

openMenuButton.addEventListener('click', abrirMenu);
closeMenuButton.addEventListener('click', fecharMenu);
overlay.addEventListener('click', fecharMenu);

// Carrega todas as candidaturas do voluntário ao abrir a página.
carregarCandidaturas();
