# iPawz — Acompanhamento de candidaturas de voluntariado

Este pacote reúne o backend atual do iPawz (cadastro/login, autenticação JWT e consulta de detalhes de vagas) com a integração da tela de acompanhamento de candidaturas enviada.

## O que esta etapa implementa

- `GET /api/candidaturas`: lista todas as candidaturas do voluntário autenticado.
- `GET /api/candidaturas?status=aceita`: filtra candidaturas aceitas.
- `GET /api/candidaturas?status=aguardando`: filtra candidaturas aguardando resposta.
- `GET /api/candidaturas?status=negada`: filtra candidaturas negadas.
- Qualquer outro valor de `status` retorna HTTP 400.
- A rota exige JWT válido e perfil `Voluntário`.
- O identificador do usuário é obtido do token validado no backend (`req.usuario.id`). A API não recebe `id_usuario` pela URL ou pelo corpo para decidir de quem são as candidaturas.
- O frontend usa o token `ipawzToken` armazenado em `sessionStorage` pelo login existente.
- Os dados dos cartões são carregados do MySQL; a lista fictícia que existia no JavaScript foi removida.

## 1. Atualizar o banco de dados

Faça backup do banco `ipawz` antes de executar alterações. Como a tabela `candidatura_voluntariado` está vazia, o novo script adiciona os campos necessários sem precisar migrar registros antigos.

No MySQL Workbench, selecione e execute uma única vez:

`backend/sql/02_candidatura_voluntariado.sql`

O script adiciona:

- `data_candidatura`: data/hora do envio, preenchida automaticamente pelo MySQL;
- `status`: começa como `aguardando`;
- `etapa`: começa como `1` e alimenta a linha do tempo;
- índice para otimizar consultas por usuário e status.

A tabela `perfil` e a coluna `usuario.id_perfil` também precisam estar configuradas conforme a etapa anterior. Se ainda não executou a migração de perfil, consulte `backend/sql/01_perfil_voluntario.sql` e execute-a antes de testar login/rota protegida.

## 2. Configurar e iniciar o backend

No terminal, entre em `backend` e execute:

```bash
npm install
```

Copie `.env.example` para `.env` e informe os dados reais do MySQL. Defina também uma chave forte em `JWT_SECRET`. Depois inicie:

```bash
npm run dev
```

A API utiliza `http://localhost:3000` por padrão.

## 3. Abrir o frontend

Abra `frontend/html/candidaturas-voluntariado.html` pelo Live Server do VS Code. O endereço deve usar uma origem permitida em `CORS_ORIGINS` no `.env` do backend. O `style.css` compartilhado está incluído no pacote; se a equipe tiver uma versão mais recente, substitua `frontend/css/style.css` pela versão oficial atual.

Faça login pela tela de login integrada ao mesmo backend e à mesma origem do Live Server. O login salva o JWT em `sessionStorage` com a chave `ipawzToken`. Depois acesse a página de acompanhamento na mesma aba/origem.

## 4. Como testar o filtro pela API

Primeiro, faça login e copie o token retornado. Envie-o no cabeçalho `Authorization`:

```http
GET http://localhost:3000/api/candidaturas
Authorization: Bearer SEU_TOKEN
```

Para filtrar:

```http
GET http://localhost:3000/api/candidaturas?status=aceita
Authorization: Bearer SEU_TOKEN
```

Status aceitos: `aceita`, `aguardando` e `negada`.

Resposta esperada (quando ainda não há candidaturas):

```json
{
  "sucesso": true,
  "quantidade": 0,
  "candidaturas": []
}
```

Acesso sem token retorna HTTP 401; perfil diferente de `Voluntário` retorna HTTP 403; status inválido retorna HTTP 400.

## 5. Formato dos dados retornados

Cada item de `candidaturas` contém `id`, `data` (dd/mm/aaaa), `status`, `etapa`, `vaga` e `instituicao`. O frontend usa esses campos para montar os cartões e a linha do tempo.

## Limites desta etapa

Esta implementação somente consulta e filtra candidaturas já existentes. Ela não cria candidaturas e não altera status/etapa. O cadastro de candidatura deve preencher `id_usuario` com o usuário autenticado, `id_voluntariado`, observações (se houver), `status='aguardando'` e `etapa=1`. A atualização posterior do status e da etapa será feita por uma funcionalidade separada, com autorização apropriada para a instituição.

O código foi verificado sintaticamente, mas a conexão e as consultas precisam ser testadas no MySQL do ambiente local, com as credenciais configuradas no `.env`.
