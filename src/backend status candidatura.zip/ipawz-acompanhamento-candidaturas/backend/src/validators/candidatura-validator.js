const STATUS_PERMITIDOS = ['aceita', 'aguardando', 'negada'];

function validarFiltroStatus(req, res, next) {
    const { status } = req.query;

    if (status === undefined) return next();

    if (typeof status !== 'string' || !STATUS_PERMITIDOS.includes(status)) {
        return res.status(400).json({
            sucesso: false,
            mensagem: 'Status inválido. Utilize: aceita, aguardando ou negada.'
        });
    }

    return next();
}

module.exports = { validarFiltroStatus };
