const { body, validationResult } = require('express-validator');

const validarCadastro = [
    body('nome').trim().notEmpty().withMessage('Nome é obrigatório.'),
    body('cpf').trim().matches(/^\d{11}$/).withMessage('CPF deve conter 11 números, sem pontuação.'),
    body('dataNascimento').isISO8601({ strict: true }).withMessage('Data de nascimento inválida.'),
    body('telefone').trim().notEmpty().withMessage('Telefone é obrigatório.'),
    body('estado').trim().isLength({ min: 2, max: 2 }).withMessage('Informe a UF com duas letras.'),
    body('email').isEmail().withMessage('E-mail inválido.').normalizeEmail(),
    body('senha').isLength({ min: 8 }).withMessage('A senha deve ter pelo menos 8 caracteres.')
];

const validarLogin = [
    body('email').isEmail().withMessage('E-mail inválido.').normalizeEmail(),
    body('senha').notEmpty().withMessage('Senha é obrigatória.')
];

function tratarErros(req, res, next) {
    const erros = validationResult(req);
    if (!erros.isEmpty()) {
        return res.status(400).json({ sucesso: false, mensagem: 'Dados inválidos.', erros: erros.array() });
    }
    next();
}

module.exports = { validarCadastro, validarLogin, tratarErros };
