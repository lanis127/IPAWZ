const Joi = require('joi');

// O ID vem da URL. Aceitamos somente inteiros positivos e seguros.
const idVagaSchema = Joi.object({
    id: Joi.number().integer().positive().max(2147483647).required()
});

function validarIdVaga(req, res, next) {
    const { error, value } = idVagaSchema.validate(req.params, {
        abortEarly: false,
        convert: true
    });

    if (error) {
        return res.status(400).json({
            sucesso: false,
            mensagem: 'Identificador da vaga inválido.',
            erros: error.details.map((item) => item.message)
        });
    }

    req.params.id = value.id;
    next();
}

module.exports = { validarIdVaga };
