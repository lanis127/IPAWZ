const { pool } = require('../config/database');

async function buscarPorId(id) {
    // Parâmetro ? impede que o valor recebido na URL seja concatenado ao SQL.
    const sql = `
        SELECT
            v.id_voluntariado,
            v.titulo,
            v.descricao,
            v.requisitos,
            v.local,
            v.data_inicio,
            v.data_fim,
            v.quantidade_vagas,
            v.status,
            i.id_instituicao,
            i.nome_fantasia AS instituicao_nome,
            i.email AS instituicao_email,
            i.telefone AS instituicao_telefone,
            i.cidade AS instituicao_cidade,
            i.estado AS instituicao_estado
        FROM voluntariado v
        LEFT JOIN instituicao i
            ON i.id_instituicao = v.id_instituicao
        WHERE v.id_voluntariado = ?
        LIMIT 1
    `;

    const [linhas] = await pool.execute(sql, [id]);
    return linhas[0] || null;
}

module.exports = { buscarPorId };
