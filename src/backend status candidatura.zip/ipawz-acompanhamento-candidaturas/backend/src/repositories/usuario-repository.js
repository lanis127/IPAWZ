const { pool } = require('../config/database');

async function buscarPorEmail(email) {
    const [rows] = await pool.execute(
        `SELECT u.id_usuario, u.nome, u.email, u.senha_hash, u.status,
                p.id_perfil, p.nome AS perfil
         FROM usuario u
         INNER JOIN perfil p ON p.id_perfil = u.id_perfil
         WHERE u.email = ? LIMIT 1`,
        [email]
    );
    return rows[0] || null;
}

async function buscarPorId(id) {
    const [rows] = await pool.execute(
        `SELECT u.id_usuario, u.nome, u.email, u.status,
                p.id_perfil, p.nome AS perfil
         FROM usuario u
         INNER JOIN perfil p ON p.id_perfil = u.id_perfil
         WHERE u.id_usuario = ? LIMIT 1`,
        [id]
    );
    return rows[0] || null;
}

async function emailExiste(email) {
    const [rows] = await pool.execute('SELECT id_usuario FROM usuario WHERE email = ? LIMIT 1', [email]);
    return rows.length > 0;
}

async function cadastrar(dados) {
    const [result] = await pool.execute(
        `INSERT INTO usuario
         (nome, cpf, data_nascimento, email, senha_hash, telefone, estado, id_perfil)
         VALUES (?, ?, ?, ?, ?, ?, ?,
             (SELECT id_perfil FROM perfil WHERE nome = 'Voluntário' LIMIT 1))`,
        [dados.nome, dados.cpf, dados.dataNascimento, dados.email,
         dados.senhaHash, dados.telefone, dados.estado]
    );
    return result.insertId;
}

module.exports = { buscarPorEmail, buscarPorId, emailExiste, cadastrar };
