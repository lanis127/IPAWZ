const { pool } = require('../config/database');

/**
 * Busca somente as candidaturas pertencentes ao usuário autenticado.
 * O idUsuario vem do JWT validado pelo auth-middleware, nunca da query string.
 * O status é opcional: quando ausente, todas as candidaturas do usuário são retornadas.
 */
async function listarPorUsuario(idUsuario, status = null) {
    let sql = `
        SELECT
            c.id_candidatura AS id,
            DATE_FORMAT(c.data_candidatura, '%d/%m/%Y') AS data,
            c.status,
            c.etapa,
            v.titulo AS vaga,
            COALESCE(i.nome_fantasia, 'Instituição não informada') AS instituicao
        FROM candidatura_voluntariado c
        INNER JOIN voluntariado v
            ON v.id_voluntariado = c.id_voluntariado
        LEFT JOIN instituicao i
            ON i.id_instituicao = v.id_instituicao
        WHERE c.id_usuario = ?
    `;

    const parametros = [idUsuario];

    if (status) {
        sql += ' AND c.status = ?';
        parametros.push(status);
    }

    sql += ' ORDER BY c.data_candidatura DESC, c.id_candidatura DESC';

    const [linhas] = await pool.execute(sql, parametros);
    return linhas;
}

module.exports = { listarPorUsuario };
