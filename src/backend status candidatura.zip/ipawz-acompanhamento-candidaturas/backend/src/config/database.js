const mysql = require('mysql2/promise');

// Pool reutiliza conexões e evita abrir uma conexão nova a cada requisição.
const pool = mysql.createPool({
    host: process.env.DB_HOST,
    port: Number(process.env.DB_PORT || 3306),
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
    charset: 'utf8mb4',
    dateStrings: true
});

async function testarConexao() {
    const conexao = await pool.getConnection();
    try {
        await conexao.query('SELECT 1');
    } finally {
        conexao.release();
    }
}

module.exports = { pool, testarConexao };
