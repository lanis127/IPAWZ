const service = require('../services/auth-service');

async function cadastrar(req, res, next) {
    try {
        const usuario = await service.cadastrarVoluntario(req.body);
        return res.status(201).json({ sucesso: true, mensagem: 'Cadastro realizado como voluntário.', usuario });
    } catch (erro) { next(erro); }
}

async function login(req, res, next) {
    try {
        const resultado = await service.realizarLogin(req.body.email, req.body.senha);
        return res.status(200).json({ sucesso: true, mensagem: 'Login realizado com sucesso.', ...resultado });
    } catch (erro) { next(erro); }
}

module.exports = { cadastrar, login };
