const service = require('../services/candidatura-service');

async function listarMinhas(req, res, next) {
    try {
        // req.usuario.id é preenchido pelo middleware após validar o JWT.
        const candidaturas = await service.listarMinhasCandidaturas(
            req.usuario.id,
            req.query.status
        );

        return res.status(200).json({
            sucesso: true,
            quantidade: candidaturas.length,
            candidaturas
        });
    } catch (erro) {
        return next(erro);
    }
}

module.exports = { listarMinhas };
