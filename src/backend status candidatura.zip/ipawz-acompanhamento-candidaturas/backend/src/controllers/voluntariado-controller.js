const service = require('../services/voluntariado-service');

async function buscarDetalhes(req, res, next) {
    try {
        const vaga = await service.obterDetalhes(req.params.id);
        return res.status(200).json({ sucesso: true, dados: vaga });
    } catch (erro) {
        next(erro);
    }
}

module.exports = { buscarDetalhes };
