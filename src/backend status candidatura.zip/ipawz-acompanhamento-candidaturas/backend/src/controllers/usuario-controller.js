function permissoes(req, res) {
    const voluntario = req.usuario.perfil === 'Voluntário';
    return res.status(200).json({
        sucesso: true,
        usuario: req.usuario,
        permissoes: {
            realizarDoacao: voluntario,
            candidatarSeVoluntariado: voluntario,
            acompanharCandidaturas: voluntario,
            solicitarAdocao: false,
            acompanharAdocao: false
        }
    });
}
module.exports = { permissoes };
