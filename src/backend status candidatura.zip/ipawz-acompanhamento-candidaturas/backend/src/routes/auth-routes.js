const express = require('express');
const controller = require('../controllers/auth-controller');
const { validarCadastro, validarLogin, tratarErros } = require('../validators/auth-validator');

const router = express.Router();
router.post('/cadastro', validarCadastro, tratarErros, controller.cadastrar);
router.post('/login', validarLogin, tratarErros, controller.login);
module.exports = router;
