const express = require('express');
const autenticar = require('../middlewares/auth-middleware');
const { exigirPerfil } = require('../middlewares/perfil-middleware');
const { validarFiltroStatus } = require('../validators/candidatura-validator');
const controller = require('../controllers/candidatura-controller');

const router = express.Router();

// A listagem é exclusiva do voluntário e exige autenticação.
router.get('/', autenticar, exigirPerfil('Voluntário'), validarFiltroStatus, controller.listarMinhas);

module.exports = router;
