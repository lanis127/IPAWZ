const express = require('express');
const controller = require('../controllers/voluntariado-controller');
const { validarIdVaga } = require('../validators/voluntariado-validator');

const router = express.Router();
router.get('/:id', validarIdVaga, controller.buscarDetalhes);

module.exports = router;
