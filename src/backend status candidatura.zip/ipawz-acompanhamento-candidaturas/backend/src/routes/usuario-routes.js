const express = require('express');
const autenticar = require('../middlewares/auth-middleware');
const controller = require('../controllers/usuario-controller');
const router = express.Router();
router.get('/permissoes', autenticar, controller.permissoes);
module.exports = router;
