require('dotenv').config();
const app = require('./app');
const { testarConexao } = require('./config/database');

const PORT = Number(process.env.PORT || 3000);

async function iniciarServidor() {
    try {
        await testarConexao();
        console.log('Conexão com o MySQL estabelecida.');
        app.listen(PORT, () => console.log(`API iPawz executando na porta ${PORT}.`));
    } catch (erro) {
        console.error('Não foi possível conectar ao MySQL:', erro.message);
        process.exit(1);
    }
}

iniciarServidor();
