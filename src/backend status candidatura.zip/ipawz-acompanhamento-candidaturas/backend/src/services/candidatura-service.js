const repository = require('../repositories/candidatura-repository');

const STATUS_PERMITIDOS = ['aceita', 'aguardando', 'negada'];

function criarErro(statusCode, mensagem) {
    const erro = new Error(mensagem);
    erro.statusCode = statusCode;
    return erro;
}

async function listarMinhasCandidaturas(idUsuario, status) {
    if (status !== undefined && !STATUS_PERMITIDOS.includes(status)) {
        throw criarErro(400, 'Status inválido. Utilize: aceita, aguardando ou negada.');
    }

    return repository.listarPorUsuario(idUsuario, status || null);
}

module.exports = { listarMinhasCandidaturas, STATUS_PERMITIDOS };
