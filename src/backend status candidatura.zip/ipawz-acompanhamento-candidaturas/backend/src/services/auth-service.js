const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const repository = require('../repositories/usuario-repository');

function erroHttp(statusCode, mensagem) {
    const erro = new Error(mensagem);
    erro.statusCode = statusCode;
    return erro;
}

async function cadastrarVoluntario(dados) {
    if (await repository.emailExiste(dados.email)) {
        throw erroHttp(409, 'Este e-mail já está cadastrado.');
    }

    const senhaHash = await bcrypt.hash(dados.senha, 12);
    const id = await repository.cadastrar({ ...dados, senhaHash });
    return { id, nome: dados.nome, email: dados.email, perfil: 'Voluntário' };
}

async function realizarLogin(email, senha) {
    const usuario = await repository.buscarPorEmail(email);
    if (!usuario || !usuario.status) {
        throw erroHttp(401, 'E-mail ou senha inválidos.');
    }

    const senhaCorreta = await bcrypt.compare(senha, usuario.senha_hash);
    if (!senhaCorreta) throw erroHttp(401, 'E-mail ou senha inválidos.');

    if (!process.env.JWT_SECRET) {
        throw new Error('JWT_SECRET não foi configurado no arquivo .env.');
    }

    const token = jwt.sign(
        { id: usuario.id_usuario, email: usuario.email, perfil: usuario.perfil },
        process.env.JWT_SECRET,
        { expiresIn: process.env.JWT_EXPIRES_IN || '1h', subject: String(usuario.id_usuario) }
    );

    return {
        token,
        usuario: {
            id: usuario.id_usuario,
            nome: usuario.nome,
            email: usuario.email,
            perfil: usuario.perfil
        }
    };
}

module.exports = { cadastrarVoluntario, realizarLogin };
