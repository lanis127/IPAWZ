const repository = require('../repositories/voluntariado-repository');

async function obterDetalhes(id) {
    const vaga = await repository.buscarPorId(id);

    if (!vaga) {
        const erro = new Error('Vaga de voluntariado não encontrada.');
        erro.statusCode = 404;
        throw erro;
    }

    // A tabela atual não possui coluna "tipo" ou imagem. Não inventamos esses dados:
    // requisitos é retornado separadamente e a imagem permanece no frontend.
    return {
        id: vaga.id_voluntariado,
        titulo: vaga.titulo,
        descricao: vaga.descricao,
        requisitos: vaga.requisitos,
        local: vaga.local,
        dataInicio: vaga.data_inicio,
        dataFim: vaga.data_fim,
        quantidadeVagas: vaga.quantidade_vagas,
        status: vaga.status,
        instituicao: vaga.id_instituicao ? {
            id: vaga.id_instituicao,
            nome: vaga.instituicao_nome,
            email: vaga.instituicao_email,
            telefone: vaga.instituicao_telefone,
            cidade: vaga.instituicao_cidade,
            estado: vaga.instituicao_estado
        } : null
    };
}

module.exports = { obterDetalhes };
