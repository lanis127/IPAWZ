function exigirPerfil(...perfisPermitidos) {
    return (req, res, next) => {
        if (!req.usuario) {
            return res.status(401).json({ sucesso: false, mensagem: 'É necessário realizar login.' });
        }
        if (!perfisPermitidos.includes(req.usuario.perfil)) {
            return res.status(403).json({ sucesso: false, mensagem: 'Você não tem permissão para acessar esta funcionalidade.' });
        }
        next();
    };
}

function negarPerfil(...perfisBloqueados) {
    return (req, res, next) => {
        if (!req.usuario) {
            return res.status(401).json({ sucesso: false, mensagem: 'É necessário realizar login.' });
        }
        if (perfisBloqueados.includes(req.usuario.perfil)) {
            return res.status(403).json({ sucesso: false, mensagem: 'Esta funcionalidade não está disponível para o seu perfil.' });
        }
        next();
    };
}

module.exports = { exigirPerfil, negarPerfil };
