const jwt = require('jsonwebtoken');
const repository = require('../repositories/usuario-repository');

async function autenticar(req, res, next) {
    const cabecalho = req.headers.authorization;
    if (!cabecalho || !cabecalho.startsWith('Bearer ')) {
        return res.status(401).json({ sucesso: false, mensagem: 'Autenticação necessária. Informe o token Bearer.' });
    }

    try {
        const token = cabecalho.slice(7);
        const payload = jwt.verify(token, process.env.JWT_SECRET);
        const usuario = await repository.buscarPorId(Number(payload.id));

        if (!usuario || !usuario.status) {
            return res.status(401).json({ sucesso: false, mensagem: 'Usuário inexistente ou inativo.' });
        }

        // O perfil é consultado novamente no banco; não confiamos apenas no perfil antigo do token.
        req.usuario = {
            id: usuario.id_usuario,
            nome: usuario.nome,
            email: usuario.email,
            perfil: usuario.perfil
        };
        next();
    } catch (erro) {
        if (erro.name === 'JsonWebTokenError' || erro.name === 'TokenExpiredError') {
            return res.status(401).json({ sucesso: false, mensagem: 'Token inválido ou expirado.' });
        }
        next(erro);
    }
}

module.exports = autenticar;
