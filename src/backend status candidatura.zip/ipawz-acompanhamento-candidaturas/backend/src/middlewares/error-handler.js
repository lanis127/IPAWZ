function errorHandler(erro, req, res, next) {
    console.error(erro);

    const status = erro.statusCode || 500;
    const mensagem = status === 500
        ? 'Ocorreu um erro interno ao processar a solicitação.'
        : erro.message;

    res.status(status).json({ sucesso: false, mensagem });
}

module.exports = errorHandler;
