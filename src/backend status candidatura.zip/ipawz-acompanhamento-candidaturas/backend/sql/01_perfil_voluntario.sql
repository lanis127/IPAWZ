USE ipawz;

-- 1. Corrige o tamanho do CPF: CPF possui 11 dígitos.
ALTER TABLE usuario MODIFY cpf CHAR(11) NOT NULL;

-- 2. Cria o perfil voluntário sem duplicá-lo se o script for executado novamente.
INSERT INTO perfil (nome, descricao)
VALUES ('Voluntário', 'Usuário pessoa física que pode doar e participar de oportunidades de voluntariado')
ON DUPLICATE KEY UPDATE descricao = VALUES(descricao);

-- 3. Adiciona a referência ao perfil. Primeiro como NULL para permitir migração dos registros existentes.
ALTER TABLE usuario ADD COLUMN id_perfil INT NULL;

-- 4. Atribui o perfil Voluntário aos usuários pessoa física já cadastrados.
UPDATE usuario
SET id_perfil = (SELECT id_perfil FROM perfil WHERE nome = 'Voluntário' LIMIT 1)
WHERE id_perfil IS NULL;

-- 5. Torna o relacionamento obrigatório e cria a chave estrangeira.
ALTER TABLE usuario MODIFY id_perfil INT NOT NULL;
ALTER TABLE usuario
ADD CONSTRAINT fk_usuario_perfil
FOREIGN KEY (id_perfil) REFERENCES perfil(id_perfil);

CREATE INDEX idx_usuario_perfil ON usuario(id_perfil);
