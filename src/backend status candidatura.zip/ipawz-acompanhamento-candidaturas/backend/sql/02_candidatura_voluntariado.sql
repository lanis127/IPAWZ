USE ipawz;

-- A tabela candidatura_voluntariado está vazia neste projeto.
-- Este script deve ser executado uma única vez.
-- O status inicial será 'aguardando' para novas candidaturas.

ALTER TABLE candidatura_voluntariado
    ADD COLUMN data_candidatura DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    ADD COLUMN status ENUM('aceita', 'aguardando', 'negada') NOT NULL DEFAULT 'aguardando',
    ADD COLUMN etapa TINYINT UNSIGNED NOT NULL DEFAULT 1;

-- Índice para acelerar a listagem por usuário e o filtro por status.
CREATE INDEX idx_candidatura_usuario_status_data
    ON candidatura_voluntariado (id_usuario, status, data_candidatura);

-- Valores aceitos pelo filtro: aceita, aguardando e negada.
-- A validação da API também limita os valores recebidos pela URL.
