# iPawz — backend da listagem de pets

Projeto inicial de integração da listagem de pets do frontend com MySQL usando Node.js e Express.

## Estrutura

- `backend/`: API Express.
- `frontend/`: frontend do ZIP original, com `js/listagem-pets.js` adaptado para consumir a API e montar os cards dinamicamente. As imagens locais foram preservadas.

## 1. Requisitos

- Node.js LTS instalado.
- MySQL em execução e banco `ipawz` criado com o script SQL do projeto.
- VS Code (recomendado).

## 2. Configurar o backend

Abra um terminal na pasta `backend` e execute:

```bash
npm install
```

Copie `.env.example` para `.env` e preencha a senha correta do MySQL. Exemplo:

```env
PORT=3000
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=sua_senha_mysql
DB_NAME=ipawz
CORS_ORIGINS=http://127.0.0.1:5500,http://localhost:5500
```

Não compartilhe o `.env` nem envie sua senha para repositórios públicos.

## 3. Iniciar a API

Na pasta `backend`:

```bash
npm run dev
```

ou `npm start`.

O servidor testa a conexão com o MySQL antes de iniciar. Se houver erro, confira as credenciais, o serviço MySQL e o nome do banco.

## 4. Endpoints

- `GET http://localhost:3000/api/health` — verifica se a API está funcionando.
- `GET http://localhost:3000/api/pets` — lista até 9 pets disponíveis.
- `GET http://localhost:3000/api/pets?page=2&limit=9` — consulta outra página.
- `GET http://localhost:3000/api/pets?especie=Cachorro` — filtra por espécie.
- `GET http://localhost:3000/api/pets?busca=duke` — pesquisa por nome ou raça.

A resposta inclui `dados` e `paginacao`. Quando o banco responde corretamente, mas não há pets disponíveis que correspondam aos filtros, a API retorna os nove exemplos do frontend. Se o banco estiver indisponível, a API informa erro em vez de esconder o problema usando os exemplos.

## 5. Abrir o frontend

Abra a pasta `frontend` no VS Code e inicie `index.html` com a extensão Live Server. Se o Live Server usar uma porta diferente de 5500, adicione essa origem em `CORS_ORIGINS` no `.env` e reinicie a API.

## Observações

- Os exemplos de fallback não são inseridos no banco.
- Para os nomes dos nove pets originais, a API associa as imagens locais já existentes na pasta `frontend/img`.
- Pets novos com nome diferente usam `foto_url` quando esse campo contém caminho/URL válido; caso contrário, recebem a imagem local padrão.
- A listagem é pública. JWT será apropriado para rotas protegidas, como envio de uma solicitação de adoção, quando essa funcionalidade for implementada.
