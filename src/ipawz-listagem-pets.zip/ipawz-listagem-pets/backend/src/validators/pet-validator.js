const Joi = require('joi');

const listarPetsSchema = Joi.object({
  page: Joi.number().integer().min(1).default(1),
  limit: Joi.number().integer().min(1).max(50).default(9),
  especie: Joi.string().trim().max(50).optional(),
  busca: Joi.string().trim().max(100).optional()
}).unknown(false);

function validarListagem(req, res, next) {
  const { error, value } = listarPetsSchema.validate(req.query, {
    abortEarly: false,
    convert: true
  });

  if (error) {
    return res.status(400).json({
      erro: 'Parâmetros de consulta inválidos.',
      detalhes: error.details.map((item) => item.message)
    });
  }

  req.queryValidada = value;
  next();
}

module.exports = { validarListagem };
