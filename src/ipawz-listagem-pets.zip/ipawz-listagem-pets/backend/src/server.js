require('dotenv').config();
const app = require('./app');
const pool = require('./config/database');

const port = Number(process.env.PORT || 3000);

async function iniciarServidor() {
  try {
    // Testa a conexão antes de aceitar requisições.
    const conexao = await pool.getConnection();
    await conexao.ping();
    conexao.release();
    console.log('Conexão com MySQL estabelecida.');

    app.listen(port, () => {
      console.log(`API iPawz executando em http://localhost:${port}`);
      console.log(`Listagem de pets: http://localhost:${port}/api/pets`);
    });
  } catch (error) {
    console.error('Não foi possível conectar ao MySQL. Confira o arquivo .env.', error.message);
    process.exit(1);
  }
}

iniciarServidor();
