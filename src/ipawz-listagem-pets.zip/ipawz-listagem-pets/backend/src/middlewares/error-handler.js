function errorHandler(error, req, res, next) {
  console.error('Erro na API:', error.message);

  if (res.headersSent) return next(error);

  return res.status(500).json({
    erro: 'Não foi possível carregar os pets neste momento.'
  });
}

module.exports = errorHandler;
