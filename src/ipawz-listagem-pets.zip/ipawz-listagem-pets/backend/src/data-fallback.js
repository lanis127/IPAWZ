// Dados de demonstração usados somente quando a consulta ao banco funciona,
// mas não há pets disponíveis cadastrados. Não são inseridos no MySQL.
const petsFallback = [
  { id_pet: 'demo-duke', nome: 'Duke', especie: 'Cachorro', idade: 6, foto_url: null, status: 'Disponível' },
  { id_pet: 'demo-zoe', nome: 'Zoe', especie: 'Cachorro', idade: 2, foto_url: null, status: 'Disponível' },
  { id_pet: 'demo-nala-filhote', nome: 'Nala', especie: 'Gato', idade: 0, idade_texto: '3 meses', foto_url: null, status: 'Disponível' },
  { id_pet: 'demo-salem', nome: 'Salém', especie: 'Gato', idade: 5, foto_url: null, status: 'Disponível' },
  { id_pet: 'demo-nazinha', nome: 'Nazinha', especie: 'Gato', idade: 7, foto_url: null, status: 'Disponível' },
  { id_pet: 'demo-pipoca', nome: 'Pipoca', especie: 'Cachorro', idade: 4, foto_url: null, status: 'Disponível' },
  { id_pet: 'demo-loro', nome: 'Loro', especie: 'Ave', idade: 2, foto_url: null, status: 'Disponível' },
  { id_pet: 'demo-marley', nome: 'Marley', especie: 'Cachorro', idade: 0, idade_texto: '4 meses', foto_url: null, status: 'Disponível' },
  { id_pet: 'demo-nala-adulta', nome: 'Nala', especie: 'Gato', idade: 3, foto_url: null, status: 'Disponível' }
];

module.exports = petsFallback;
