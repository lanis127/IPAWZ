const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const petRoutes = require('./routes/pet-routes');
const errorHandler = require('./middlewares/error-handler');

const app = express();
const origensPermitidas = (process.env.CORS_ORIGINS || 'http://localhost:5500,http://127.0.0.1:5500')
  .split(',')
  .map((origem) => origem.trim());

app.use(helmet());
app.use(cors({
  origin(origem, callback) {
    // Permite chamadas sem Origin, por exemplo teste local via curl/Postman.
    if (!origem || origensPermitidas.includes(origem)) return callback(null, true);
    return callback(new Error('Origem não permitida pelo CORS.'));
  }
}));
app.use(express.json({ limit: '10kb' }));

app.get('/api/health', (req, res) => res.json({ status: 'ok', aplicacao: 'iPawz API' }));
app.use('/api/pets', petRoutes);
app.use((req, res) => res.status(404).json({ erro: 'Rota não encontrada.' }));
app.use(errorHandler);

module.exports = app;
