const petService = require('../services/pet-service');

async function listar(req, res, next) {
  try {
    const resultado = await petService.obterListagem(req.queryValidada);
    return res.status(200).json(resultado);
  } catch (error) {
    next(error);
  }
}

module.exports = { listar };
