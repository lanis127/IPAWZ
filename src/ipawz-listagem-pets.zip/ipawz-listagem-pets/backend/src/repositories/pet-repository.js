const pool = require('../config/database');

async function contarTodosPets() {
  const [rows] = await pool.execute('SELECT COUNT(*) AS total FROM pet');
  return Number(rows[0].total);
}

async function contarPets({ especie, busca }) {
  const condicoes = ["p.status = ?"];
  const parametros = ['Disponível'];

  if (especie) {
    condicoes.push('p.especie = ?');
    parametros.push(especie);
  }

  if (busca) {
    condicoes.push('(p.nome LIKE ? OR p.raca LIKE ?)');
    parametros.push(`%${busca}%`, `%${busca}%`);
  }

  const sql = `SELECT COUNT(*) AS total FROM pet p WHERE ${condicoes.join(' AND ')}`;
  const [rows] = await pool.execute(sql, parametros);
  return Number(rows[0].total);
}

async function listarPets({ page, limit, especie, busca }) {
  const condicoes = ["p.status = ?"];
  const parametros = ['Disponível'];

  if (especie) {
    condicoes.push('p.especie = ?');
    parametros.push(especie);
  }

  if (busca) {
    condicoes.push('(p.nome LIKE ? OR p.raca LIKE ?)');
    parametros.push(`%${busca}%`, `%${busca}%`);
  }

  const offset = (page - 1) * limit;
  // Os valores de filtro são parâmetros; LIMIT/OFFSET são convertidos para números
  // após a validação Joi, sem concatenar entrada textual do usuário na consulta.
  const sql = `
    SELECT p.id_pet, p.id_instituicao, p.nome, p.especie, p.raca,
           p.idade, p.sexo, p.porte, p.descricao, p.foto_url, p.status,
           i.nome_fantasia AS instituicao_nome
    FROM pet p
    LEFT JOIN instituicao i ON i.id_instituicao = p.id_instituicao
    WHERE ${condicoes.join(' AND ')}
    ORDER BY p.data_cadastro DESC, p.id_pet DESC
    LIMIT ${Number(limit)} OFFSET ${Number(offset)}
  `;

  const [rows] = await pool.execute(sql, parametros);
  return rows;
}

module.exports = { contarTodosPets, contarPets, listarPets };
