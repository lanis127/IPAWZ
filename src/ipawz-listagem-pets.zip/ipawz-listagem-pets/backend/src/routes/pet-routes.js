const express = require('express');
const petController = require('../controllers/pet-controller');
const { validarListagem } = require('../validators/pet-validator');

const router = express.Router();

// A listagem é pública, pois visitantes precisam poder conhecer os pets disponíveis.
router.get('/', validarListagem, petController.listar);

module.exports = router;
