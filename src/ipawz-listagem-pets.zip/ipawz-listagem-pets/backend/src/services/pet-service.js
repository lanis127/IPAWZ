const petRepository = require('../repositories/pet-repository');
const petsFallback = require('../data-fallback');

// Relaciona os nomes que aparecem no frontend às imagens que já estão no ZIP.
const imagensPorNome = {
  duke: 'img/duke.jpg',
  zoe: 'img/zoe.jpg',
  nala: 'img/nala.jpg',
  salem: 'img/salem.jpg',
  nazinha: 'img/nazinha.jpg',
  pipoca: 'img/pipoca.jpg',
  loro: 'img/loro.jpg',
  marley: 'img/marley.jpg'
};
const imagemPadrao = 'img/duke.jpg';

function normalizarNome(nome = '') {
  return nome.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();
}

function resolverImagem(pet) {
  // Quando o nome corresponde a um dos exemplos do frontend, usa a imagem local.
  const imagemLocal = imagensPorNome[normalizarNome(pet.nome)];
  if (imagemLocal) {
    // Para as duas Nalas, diferencia a foto pelo identificador demonstrativo.
    if (String(pet.id_pet) === 'demo-nala-adulta') return 'img/nala2.jpg';
    return imagemLocal;
  }

  // Pets novos podem usar foto_url caso seja um caminho ou URL válido.
  if (pet.foto_url && /^https?:\/\//i.test(pet.foto_url)) return pet.foto_url;
  if (pet.foto_url && /^[a-zA-Z0-9_./-]+$/.test(pet.foto_url)) return pet.foto_url;
  return imagemPadrao;
}

function formatarPet(pet) {
  return {
    id: pet.id_pet,
    nome: pet.nome,
    especie: pet.especie,
    raca: pet.raca || null,
    idade: pet.idade,
    idadeTexto: pet.idade_texto || null,
    sexo: pet.sexo || null,
    porte: pet.porte || null,
    descricao: pet.descricao || null,
    status: pet.status,
    imagem: resolverImagem(pet),
    instituicao: pet.instituicao_nome || null
  };
}

async function obterListagem({ page, limit, especie, busca }) {
  // Se o banco responder sem pets disponíveis, usamos os nove exemplos do frontend.
  // Erros de conexão não são escondidos: eles devem retornar erro e ser corrigidos.
  const totalCadastradosNoBanco = await petRepository.contarTodosPets();
  const totalBanco = await petRepository.contarPets({ especie, busca });

  if (totalCadastradosNoBanco === 0) {
    let pets = petsFallback;
    if (especie) {
      pets = pets.filter((pet) => pet.especie.toLowerCase() === especie.toLowerCase());
    }
    if (busca) {
      const termo = busca.toLocaleLowerCase('pt-BR');
      pets = pets.filter((pet) => pet.nome.toLocaleLowerCase('pt-BR').includes(termo));
    }

    const total = pets.length;
    const totalPaginas = Math.ceil(total / limit);
    const inicio = (page - 1) * limit;
    return {
      dados: pets.slice(inicio, inicio + limit).map(formatarPet),
      paginacao: { pagina: page, limite: limit, total, totalPaginas, origem: 'fallback' }
    };
  }

  const pets = await petRepository.listarPets({ page, limit, especie, busca });
  return {
    dados: pets.map(formatarPet),
    paginacao: {
      pagina: page,
      limite: limit,
      total: totalBanco,
      totalPaginas: Math.ceil(totalBanco / limit),
      origem: 'mysql'
    }
  };
}

module.exports = { obterListagem };
