// =====================================================
// LISTAGEM DE PETS CONSUMINDO A API DO IPAWZ
// =====================================================

const API_PETS = 'http://localhost:3000/api/pets';
const listaPets = document.querySelector('.lista-pets');
const navPaginacao = document.querySelector('.paginacao');
const areaPets = document.querySelector('.pagina-adocao');

let paginaAtual = 1;
const limitePorPagina = 9;
let totalPaginas = 1;
let requisicaoAtual = null;

function formatarIdade(pet) {
    if (pet.idadeTexto) return pet.idadeTexto;
    if (pet.idade === null || pet.idade === undefined || pet.idade === '') return 'idade não informada';

    const idade = Number(pet.idade);
    if (!Number.isFinite(idade)) return 'idade não informada';
    if (idade === 1) return '1 ano';
    return `${idade} anos`;
}

function textoDoCard(pet) {
    return `${String(pet.nome || 'Pet').toLocaleUpperCase('pt-BR')}, ${formatarIdade(pet).toLocaleUpperCase('pt-BR')}`;
}

function criarCard(pet) {
    const article = document.createElement('article');
    article.className = 'card-pet';
    article.dataset.petId = String(pet.id);

    const imagem = document.createElement('img');
    imagem.src = pet.imagem || 'img/duke.jpg';
    imagem.alt = `${pet.nome || 'Pet'}${pet.especie ? `, ${pet.especie.toLowerCase()}` : ''}`;
    imagem.loading = 'lazy';
    imagem.addEventListener('error', () => {
        imagem.src = 'img/duke.jpg';
    }, { once: true });

    const nome = document.createElement('div');
    nome.className = 'nome-pet';
    nome.textContent = textoDoCard(pet);

    const link = document.createElement('a');
    link.href = '#';
    link.className = 'conheca-mais';
    link.textContent = 'CONHEÇA MAIS';
    link.setAttribute('aria-label', `Conheça mais sobre ${pet.nome || 'este pet'}`);
    // A tela de detalhamento ainda não faz parte deste escopo.
    link.addEventListener('click', (event) => event.preventDefault());

    article.append(imagem, nome, link);
    return article;
}

function exibirMensagem(mensagem) {
    listaPets.replaceChildren();
    const paragrafo = document.createElement('p');
    paragrafo.className = 'mensagem-listagem';
    paragrafo.textContent = mensagem;
    listaPets.appendChild(paragrafo);
}

function renderizarPaginacao(paginacao) {
    navPaginacao.replaceChildren();
    totalPaginas = Math.max(1, Number(paginacao.totalPaginas) || 1);

    const anterior = document.createElement('button');
    anterior.className = 'seta-paginacao';
    anterior.id = 'paginaAnterior';
    anterior.type = 'button';
    anterior.setAttribute('aria-label', 'Página anterior');
    anterior.textContent = '‹';
    anterior.disabled = paginaAtual <= 1;
    anterior.addEventListener('click', () => carregarPets(paginaAtual - 1));
    navPaginacao.appendChild(anterior);

    for (let numero = 1; numero <= totalPaginas; numero += 1) {
        const botao = document.createElement('button');
        botao.className = `numero-pagina${numero === paginaAtual ? ' ativa' : ''}`;
        botao.dataset.pagina = String(numero);
        botao.type = 'button';
        botao.textContent = String(numero);
        if (numero === paginaAtual) botao.setAttribute('aria-current', 'page');
        botao.addEventListener('click', () => carregarPets(numero));
        navPaginacao.appendChild(botao);
    }

    const proxima = document.createElement('button');
    proxima.className = 'seta-paginacao';
    proxima.id = 'paginaProxima';
    proxima.type = 'button';
    proxima.setAttribute('aria-label', 'Próxima página');
    proxima.textContent = '›';
    proxima.disabled = paginaAtual >= totalPaginas;
    proxima.addEventListener('click', () => carregarPets(paginaAtual + 1));
    navPaginacao.appendChild(proxima);
}

async function carregarPets(novaPagina = 1) {
    if (novaPagina < 1 || novaPagina > totalPaginas) return;
    paginaAtual = novaPagina;

    if (requisicaoAtual) requisicaoAtual.abort();
    requisicaoAtual = new AbortController();

    listaPets.setAttribute('aria-busy', 'true');
    try {
        const parametros = new URLSearchParams({
            page: String(paginaAtual),
            limit: String(limitePorPagina)
        });
        const resposta = await fetch(`${API_PETS}?${parametros.toString()}`, {
            method: 'GET',
            headers: { Accept: 'application/json' },
            signal: requisicaoAtual.signal
        });

        if (!resposta.ok) throw new Error(`A API respondeu com status ${resposta.status}.`);
        const resultado = await resposta.json();
        const pets = Array.isArray(resultado.dados) ? resultado.dados : [];

        if (pets.length === 0) {
            exibirMensagem('Nenhum pet encontrado nesta página.');
        } else {
            listaPets.replaceChildren(...pets.map(criarCard));
        }

        renderizarPaginacao(resultado.paginacao || { pagina: paginaAtual, totalPaginas: 1 });
    } catch (erro) {
        if (erro.name === 'AbortError') return;
        console.error('Não foi possível carregar os pets:', erro);
        exibirMensagem('Não foi possível carregar os pets. Confira se a API do iPawz está em execução e tente novamente.');
    } finally {
        listaPets.removeAttribute('aria-busy');
    }
}

// O backend fornece os dados reais do MySQL ou os nove exemplos de fallback.
document.addEventListener('DOMContentLoaded', () => carregarPets(1));
